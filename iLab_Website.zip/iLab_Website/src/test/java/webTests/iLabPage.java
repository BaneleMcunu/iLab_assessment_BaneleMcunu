package webTests;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import dataBase.dataSource;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;
import pageObject.functions;
import report.reporting;
import webUtilities.utilities;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Properties;

public class iLabPage extends utilities{

    public utilities web = new utilities();
    public functions fun = new functions();
    public reporting repo = new reporting ();


    String url,browser;
    ExtentReports reports;

    dataSource data = new dataSource();
    ResultSet set;


    @Parameters({"Browser","iLabUrl"})
    @BeforeTest
    public void init(String sBrowser,String sUrl){
        browser= sBrowser;
        url = sUrl;
        web.setDriver(web.initializeWebDriver(sBrowser));

        reports = repo.initializeExtentReports("reports/test.html");
    }


    @Test
    public void page() throws InterruptedException, SQLException, IOException {

        ExtentTest test = reports.createTest("iLab Webpage");
        test.assignAuthor("Banele Mchunu");
        ExtentTest node;


       try {
          set = data.ConnectAndQuerySQL("jdbc:mysql://localhost:3306/Ilab_web","root","Banele155","select * from Info");

           web.navigate(url);
            int iRow = data.rowCount(set);
            for (int i = 1; i <= iRow; i++) {
                if (set.next()) {
                    fun.navToCareers(utilities.getDriver(), test);
                    fun.navToLinkSA(utilities.getDriver(), test);
                    fun.navToFirstLink(utilities.getDriver(), test);
                    fun.navToApply(utilities.getDriver(), test);
                    fun.webForm(utilities.getDriver(),set,test);
                }
            }
            set.close();
        }catch (Exception e){
            System.out.println("Error: "+e.getMessage());
        }
}

    @AfterTest
    public void tearDown() throws InterruptedException {
        Thread.sleep(5000);
        utilities.getDriver().quit();
        reports.flush();
    }
}
