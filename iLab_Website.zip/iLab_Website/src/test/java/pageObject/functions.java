package pageObject;

import PhoneNumber.NumberGenerator;
import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.MediaEntityBuilder;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import report.reporting;
import webPageObject.*;
import webUtilities.actions;

import java.io.IOException;
import java.sql.ResultSet;

public class functions extends actions {

     reporting repo = new reporting();
     NumberGenerator randomnum = new NumberGenerator();


    public void navToCareers(WebDriver driver, ExtentTest node)
    {
        openCareersTab careersObj = new openCareersTab(driver);

        try{
            Thread.sleep(4000);
            clickObject(careersObj.careersLink,driver);
           String filename = repo.CaptureScreenShot(driver);

            if(careersObj.careersLink.isDisplayed()){

                node.pass("Successfully clicked careers tab",MediaEntityBuilder.createScreenCaptureFromBase64String(filename).build());
                System.out.println("Successfully clicked tab");

            }else {
                System.out.println("unsuccessful careers tab not clicked");
                node.fail("unsuccessful careers tab not clicked",MediaEntityBuilder.createScreenCaptureFromBase64String(filename).build());
            }
        } catch (Exception e) {
            e.printStackTrace();

        }
    }


    public void navToLinkSA(WebDriver driver,ExtentTest node) throws IOException {

        openSALink linkObj = new openSALink(driver);
        String filename = repo.CaptureScreenShot(driver);


        try {

            Thread.sleep(3000);
            clickObject(linkObj.southAfricaLink, driver);
            node.pass("successfully clicked South Africa", MediaEntityBuilder.createScreenCaptureFromBase64String(filename).build());

        } catch (Exception e) {
            e.printStackTrace();
            //node.fail("unsuccessfully, clicked careers", MediaEntityBuilder.createScreenCaptureFromBase64String(filename).build());

        }

    }


    public void navToFirstLink(WebDriver driver,ExtentTest node) throws IOException {

        openFirstLink firstObj = new openFirstLink(driver);
        String filename = repo.CaptureScreenShot(driver);

        try{
                Thread.sleep(3000);
                clickObject(firstObj.firstLink,driver);
                node.pass("Successfully clicked first link ",MediaEntityBuilder.createScreenCaptureFromBase64String(filename).build());
                System.out.println("Successfully clicked first link");

        } catch (Exception e)
        {
            node.fail("unsuccessful, first link not clicked",MediaEntityBuilder.createScreenCaptureFromBase64String(filename).build());
            e.printStackTrace();
        }

    }


    public void navToApply(WebDriver driver,ExtentTest node) throws IOException {
        openApplyLink apply = new openApplyLink(driver);
        String filename = repo.CaptureScreenShot(driver);

        try{
            Thread.sleep(3000);
                clickObject(apply.applyLink,driver);
                node.pass("Successfully clicked apply link ",MediaEntityBuilder.createScreenCaptureFromBase64String(filename).build());
                System.out.println("Successfully clicked apply link");

        } catch (Exception e) {
            e.printStackTrace();
            System.out.println("unsuccessful, apply link not clicked");
            node.fail("unsuccessful, apply link not clicked",MediaEntityBuilder.createScreenCaptureFromBase64String(filename).build());
        }
    }


   public void webForm(WebDriver driver, ResultSet rs,ExtentTest node) throws IOException {
        openApplyWebForm form = new openApplyWebForm(driver);
        String filename = repo.CaptureScreenShot(driver);

        String exp = "There are errors in your form.";
        try{

            passData(form.txtUsername,driver,rs.getString("Firstname"));
            passData(form.txtEmail,driver,rs.getString("Email"));
            passData(form.txtPhone,driver,randomnum.number());
            passData(form.txtMsg,driver,rs.getString("Message"));

            clickObject(form.submitBtn,driver);
            node.pass("Successfully filled in form  ",MediaEntityBuilder.createScreenCaptureFromBase64String(filename).build());

            if(form.txtErrorMsg.isDisplayed()){

            }else {
                String act = form.txtAlert.getText();
            }


        }catch (Exception e)
        {
            node.fail("Oops fill in form",MediaEntityBuilder.createScreenCaptureFromBase64String(filename).build());
            System.out.print("Web form not found " + e.getMessage());
        }
    }
}
